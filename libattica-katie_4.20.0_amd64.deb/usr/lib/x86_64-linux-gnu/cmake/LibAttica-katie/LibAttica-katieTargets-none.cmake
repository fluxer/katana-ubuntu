#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "LibAttica-katie::attica-katie" for configuration "None"
set_property(TARGET LibAttica-katie::attica-katie APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(LibAttica-katie::attica-katie PROPERTIES
  IMPORTED_LOCATION_NONE "/usr/lib/x86_64-linux-gnu/libattica-katie.so.0.4.2"
  IMPORTED_SONAME_NONE "libattica-katie.so.0.4"
  )

list(APPEND _IMPORT_CHECK_TARGETS LibAttica-katie::attica-katie )
list(APPEND _IMPORT_CHECK_FILES_FOR_LibAttica-katie::attica-katie "/usr/lib/x86_64-linux-gnu/libattica-katie.so.0.4.2" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
