
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was LibAtticaConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/x86_64-linux-gnu/cmake/LibAttica-katie" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

# Config file for LibAttica
# The following variables are defined:
# LibAttica_FOUND        - True if LibAttica has been found.
# LibAttica_INCLUDE_DIRS - The include directory.
# LibAttica_LIBRARY_DIRS - The libraries directory.
# LibAttica_LIBRARIES    - Libraries needed to use Attica.

########## The LibAttica version ##########
set(LibAttica_VERSION_MAJOR 0)
set(LibAttica_VERSION_MINOR 4)
set(LibAttica_VERSION_PATCH 2)
set(LibAttica_VERSION       0.4.2)
#########################################

########## Install dirs ##########
set_and_check(LibAttica_INCLUDE_DIRS "${PACKAGE_PREFIX_DIR}/include/attica-katie")
set_and_check(LibAttica_LIBRARY_DIRS "${PACKAGE_PREFIX_DIR}/lib/x86_64-linux-gnu")
##################################

########## The LibAttica libraries ##########
# Load the exported targets.
include("${CMAKE_CURRENT_LIST_DIR}/LibAttica-katieTargets.cmake")
set(LibAttica_LIBRARIES        LibAttica-katie::attica-katie)
###########################################

# The following variables are kept for compatibility purpose
set(LIBATTICA_INCLUDE_DIR ${LibAttica_INCLUDE_DIRS})
set(LIBATTICA_LIBRARY_DIRS ${LibAttica_LIBRARY_DIRS})
set(LIBATTICA_FOUND ${LibAttica_FOUND})
set(LIBATTICA_LIBRARIES ${LibAttica_LIBRARIES})

