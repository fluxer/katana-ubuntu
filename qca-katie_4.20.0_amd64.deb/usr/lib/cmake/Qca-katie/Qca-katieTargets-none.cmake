#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "qca-katie" for configuration "None"
set_property(TARGET qca-katie APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(qca-katie PROPERTIES
  IMPORTED_LOCATION_NONE "/usr/lib/libqca-katie.so.2.2.1"
  IMPORTED_SONAME_NONE "libqca-katie.so.2"
  )

list(APPEND _IMPORT_CHECK_TARGETS qca-katie )
list(APPEND _IMPORT_CHECK_FILES_FOR_qca-katie "/usr/lib/libqca-katie.so.2.2.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
