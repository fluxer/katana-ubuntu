#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "PolkitQt-1::Core" for configuration "None"
set_property(TARGET PolkitQt-1::Core APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(PolkitQt-1::Core PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Katie::DBus"
  IMPORTED_LINK_INTERFACE_LIBRARIES_NONE "Katie::Core"
  IMPORTED_LOCATION_NONE "/usr/lib/x86_64-linux-gnu/libpolkit-qt-core-1.so.1.112.0"
  IMPORTED_SONAME_NONE "libpolkit-qt-core-1.so.1"
  )

list(APPEND _IMPORT_CHECK_TARGETS PolkitQt-1::Core )
list(APPEND _IMPORT_CHECK_FILES_FOR_PolkitQt-1::Core "/usr/lib/x86_64-linux-gnu/libpolkit-qt-core-1.so.1.112.0" )

# Import target "PolkitQt-1::Gui" for configuration "None"
set_property(TARGET PolkitQt-1::Gui APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(PolkitQt-1::Gui PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Katie::Core;Katie::DBus"
  IMPORTED_LINK_INTERFACE_LIBRARIES_NONE "PolkitQt-1::Core;Katie::Gui"
  IMPORTED_LOCATION_NONE "/usr/lib/x86_64-linux-gnu/libpolkit-qt-gui-1.so.1.112.0"
  IMPORTED_SONAME_NONE "libpolkit-qt-gui-1.so.1"
  )

list(APPEND _IMPORT_CHECK_TARGETS PolkitQt-1::Gui )
list(APPEND _IMPORT_CHECK_FILES_FOR_PolkitQt-1::Gui "/usr/lib/x86_64-linux-gnu/libpolkit-qt-gui-1.so.1.112.0" )

# Import target "PolkitQt-1::Agent" for configuration "None"
set_property(TARGET PolkitQt-1::Agent APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(PolkitQt-1::Agent PROPERTIES
  IMPORTED_LINK_INTERFACE_LIBRARIES_NONE "Katie::Core;PolkitQt-1::Core"
  IMPORTED_LOCATION_NONE "/usr/lib/x86_64-linux-gnu/libpolkit-qt-agent-1.so.1.112.0"
  IMPORTED_SONAME_NONE "libpolkit-qt-agent-1.so.1"
  )

list(APPEND _IMPORT_CHECK_TARGETS PolkitQt-1::Agent )
list(APPEND _IMPORT_CHECK_FILES_FOR_PolkitQt-1::Agent "/usr/lib/x86_64-linux-gnu/libpolkit-qt-agent-1.so.1.112.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
