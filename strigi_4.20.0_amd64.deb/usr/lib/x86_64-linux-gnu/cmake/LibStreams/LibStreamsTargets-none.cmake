#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "streams" for configuration "None"
set_property(TARGET streams APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(streams PROPERTIES
  IMPORTED_LOCATION_NONE "/usr/lib/x86_64-linux-gnu/libstreams.so.0.8.0"
  IMPORTED_SONAME_NONE "libstreams.so.0"
  )

list(APPEND _IMPORT_CHECK_TARGETS streams )
list(APPEND _IMPORT_CHECK_FILES_FOR_streams "/usr/lib/x86_64-linux-gnu/libstreams.so.0.8.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
